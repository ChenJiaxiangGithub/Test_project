def f = new File(basedir, "target/hello.txt")
assert f.text == "Hello, world!"
