assert new File(basedir, "build.log").text.contains('[DEBUG] Got from cache:')
