def f = new File(basedir, "target/howdy.txt")
assert f.text == "Hello, world!"
